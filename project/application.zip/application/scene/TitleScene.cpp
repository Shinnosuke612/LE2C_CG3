#include "TitleScene.h"
#include "../../externals/imgui/imgui.h"
#include "../../engine/scene/SceneManager.h"
#include "GamePlayScene.h"
#include "../../engine/base/ImGuiManager.h"

#include "../../engine/3d/Camera.h"
#include "../../engine/3d/Object3dCommon.h"
#include "../../engine/particle/ParticleManager.h"
#include "../../engine/particle/ParticleEmitter.h"
#include "../../engine/io/Input.h"
#include "../../engine/particle/ParticleEffectResource.h"

void TitleScene::Initialize()
{
	camera_ = new Camera();
	camera_->SetOrbitMode(true);
	camera_->SetOrbitTarget({ 0.0f, 0.0f, 0.0f });
	camera_->SetOrbitDistance(10.0f);
	camera_->SetOrbitAngle(0.0f, 0.0f);
	camera_->Update();

	Object3dCommon::GetInstance()->SetDefaultCamera(camera_);
	ParticleManager::GetInstance()->SetCamera(camera_);
	ParticleManager::GetInstance()->SetGpuParticleEnabled(false);
	ParticleEffectDesc coreBurstEffect{};

	if (ParticleEffectResource::Load(
		"resources/particles/core_burst.json",
		coreBurstEffect
	)) {
		ParticleEmitter* emitter =
			ParticleEffectResource::CreateEmitter(coreBurstEffect);

		emitters_.push_back(emitter);
	}

	ParticleEffectResource::Load(
		"resources/particles/core_burst.json",
		editingEffect_
	);

	particleEffectEditor_.Initialize(
		editingEffect_,
		"resources/particles/core_burst.json"
	);

	previewEmitter_ = ParticleEffectResource::CreateEmitter(editingEffect_);

}

void TitleScene::Finalize()
{
	for (ParticleEmitter* emitter : emitters_) {
		delete emitter;
	}
	emitters_.clear();

	delete camera_;
	camera_ = nullptr;

	delete previewEmitter_;
	previewEmitter_ = nullptr;
}

void TitleScene::Update()
{
	std::string particlePath;
	if (ImGuiManager::GetInstance() && ImGuiManager::GetInstance()->GetRequestLoadParticle(particlePath)) {
		ParticleEffectDesc loadedEffect{};
		if (ParticleEffectResource::Load(particlePath, loadedEffect)) {
			editingEffect_ = loadedEffect;
			particleEffectEditor_.Initialize(
				editingEffect_,
				particlePath
			);
			delete previewEmitter_;
			previewEmitter_ = ParticleEffectResource::CreateEmitter(editingEffect_);
		}
	}

	if (Input::GetInstance()->TriggerKey(DIK_RETURN)) {
		sceneManager_->ChangeScene("GAMEPLAY");
	}

#if defined(_DEBUG) || defined(DEVELOPMENT)
	ImGui::Begin("Title Scene");
	ImGui::Text("TitleScene");
	ImGui::Text("Particles are running.");
	ImGui::End();

	camera_->DrawImGui("Main Camera");
#endif
	camera_->Update();

#if defined(_DEBUG) || defined(DEVELOPMENT)
	particleEffectEditor_.DrawImGui(editingEffect_, previewEmitter_);
	ParticleManager::GetInstance()->DrawSceneParticleImGui("TITLE", "Scene Particles");
#endif

	if (previewEmitter_) {
		previewEmitter_->Update();
	}

	for (ParticleEmitter* emitter : emitters_) {
		emitter->Update();
	}

	ParticleManager::GetInstance()->UpdateSceneParticles("TITLE");
	ParticleManager::GetInstance()->Update();
}

void TitleScene::Draw()
{
	ParticleManager::GetInstance()->Draw();
}
