#pragma once
#include "../engine/math/Vector3.h"
#include <cmath>

struct Quaternion;

struct Matrix4x4 {
float m[4][4];
};

Matrix4x4 Multiply(const Matrix4x4& m1, const Matrix4x4& m2);

Matrix4x4 MakeIdentity4x4();

Matrix4x4 MakeRotateXMatrix(float radian);

Matrix4x4 MakeRotateYMatrix(float radian);

Matrix4x4 MakeRotateZMatrix(float radian);

Matrix4x4 MakeScaleMatrix(const Vector3& scale);

Matrix4x4 MakeTranslateMatrix(const Vector3& translate);

Matrix4x4 MakeAffineMatrix(const Vector3& scale, const Vector3& rotate, const Vector3& translate);

Matrix4x4 MakeAffineMatrix(
	const Vector3& scale,
	const Quaternion& rotate,
	const Vector3& translate
);

Matrix4x4 MakePerspectiveFovMatrix(float fovY, float aspectRatio, float nearClip, float farClip);

Matrix4x4 MakeOrthographicMatrix(float left, float top, float right, float bottom, float nearClip, float farClip);

Matrix4x4 MakeViewportMatrix(float left, float top, float width, float height, float minDepth, float maxDepth);

float Cofactor(const Matrix4x4& m, int row, int col);

float Determinant(const Matrix4x4& m);

Matrix4x4 Inverse(const Matrix4x4& m);

Matrix4x4 Transpose(const Matrix4x4& m);

bool DecomposeAffineMatrix(
	const Matrix4x4& matrix,
	Vector3& scale,
	Vector3& rotate,
	Vector3& translate
);

Matrix4x4 MakeBillboardMatrix(
	const Matrix4x4& cameraWorldMatrix,
	const Vector3& scale,
	const Vector3& translate,
	float rotateZ = 0.0f
);
